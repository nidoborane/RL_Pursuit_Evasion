import gymnasium as gym
import jsbsim
import numpy as np
import plotly.graph_objects as go
import random

class BaseEnv(gym.Env):

    metadata = {"render_modes": ["human"]}

    def __init__(self, config, render_mode=None):
        super().__init__()
        self.render_mode = render_mode

        self._dt = 1 / 200
        self._sim = jsbsim.FGFDMExec(None) 
        self._sim.load_model("F16") 
        self._sim.set_dt(self._dt) 

        self._aircraft_sim_props = [
            ("velocities/v-east-fps", 0.3048),
            ("velocities/v-north-fps", 0.3048),
            ("velocities/v-down-fps", -0.3048),
            ("attitude/phi-deg", 1),
            ("attitude/theta-deg", 1),
            ("attitude/psi-deg", 1),
        ]
        
        self._prev_aircraft_position = None
        self._aircraft_position = [0.0, 0.0, 0.0] #x, y, z

        self._prev_missile_position = None
        self._missile_state = {"x" : 0.0, "y" : 0.0, "z" : 0.0,  #missile state in absolute frame
                         "u" : 0.0, "v" : 0.0, "w" : 0.0}
        self._prev_lam = None
        
        self.N = self._get_initial_config(config, "N")

        self._lethal_radius = 10
        self._min_height = 1000
        self._max_steps = self._get_initial_config(config, "max_steps")
        self._step_count = 0

        self.ac_traj = []
        self.ms_traj = []

        self._aircraft_bounds_low = np.array([-470, -470, -470, -180, -90, 0], dtype=np.float32)
        self._aircraft_bounds_high = np.array([470, 470, 470, 180, 90, 360], dtype=np.float32)

        self._missile_bounds_low = np.array([-15000, -15000, -15000, -1870, -1870, -1870], dtype=np.float32)
        self._missile_bounds_high = np.array([15000, 15000, 15000, 1870, 1870, 1870], dtype=np.float32)

        self.observation_space = gym.spaces.Dict(
            {
                "aircraft" : gym.spaces.Box(
                        low=self._aircraft_bounds_low,
                        high=self._aircraft_bounds_high,
                        shape=(6,),  
                        dtype=np.float32),
                
                "missile" : gym.spaces.Box(
                low=self._missile_bounds_low,
                high=self._missile_bounds_high,
                shape=(6,),
                dtype=np.float32)
            }
        )

        self.action_space = gym.spaces.Box(
            low=np.array([-1.0, -1.0, -1.0, 0.0], dtype=np.float32),
            high=np.array([1.0, 1.0, 1.0, 1.0], dtype=np.float32), 
            shape=(4,),
            dtype=np.float32)
        
        self._initial_h_aircraft = self._get_initial_config(config, "initial_h_ac")
        self._initial_V_aircraft = self._get_initial_config(config, "initial_v_ac")
        self._initial_roll = self._get_initial_config(config, "initial_roll")
        self._initial_pitch = self._get_initial_config(config, "initial_pitch")
        self._initial_heading = self._get_initial_config(config, "initial_heading")

        self._initial_V_missile = self._get_initial_config(config, "initial_v_ms")
        self._initial_d_missile = self._get_initial_config(config, "initial_d_ms")
        self._initial_azimuth = self._get_initial_config(config, "initial_azimuth")
        self._initial_elevation = self._get_initial_config(config, "initial_elevation")
        self._max_overload = self._get_initial_config(config, "max_overload")
    
    def _get_initial_config(self, config, item):
        value = config[item]
        if isinstance(value, list):
            if (len(value) == 2):
                return self.np_random.uniform(low=value[0], high=value[1])
            else:
                if random.random() < 0.5: return self.np_random.uniform(low=value[0], high=value[1])
                else: return self.np_random.uniform(low=value[2], high=value[3])
        return value
    
    def _set_initial_state(self):
        V_aircraft = self._initial_V_aircraft
        V_missile = self._initial_V_missile
        d_missile = self._initial_d_missile

        phi = self._initial_roll
        theta = self._initial_pitch
        psi = self._initial_heading

        azimuth = self._initial_azimuth
        elevation = self._initial_elevation

        self._sim["ic/h-sl-ft"] = self._initial_h_aircraft * 3.28084
        self._sim["ic/phi-deg"] = phi
        self._sim["ic/theta-deg"] = theta
        self._sim["ic/psi-deg"] = psi

        self._aircraft_position[2] = self._sim["ic/h-sl-ft"] * 0.3048

        self._sim["ic/u-fps"] = V_aircraft
        self._sim["ic/v-fps"] = 0.0
        self._sim["ic/w-fps"] = 0.0

        self._missile_state["x"] = -d_missile * np.cos( (psi + azimuth) * np.pi / 180) * np.cos(elevation * np.pi / 180) 
        self._missile_state["y"] = -d_missile * np.sin( (psi + azimuth) * np.pi / 180) * np.cos(elevation * np.pi / 180)
        self._missile_state["z"] = d_missile * np.sin(elevation * np.pi / 180) + self._aircraft_position[2]

        self._missile_state["u"] = V_missile * np.cos( (psi + azimuth) * np.pi / 180) * np.cos(elevation * np.pi / 180)
        self._missile_state["v"] = V_missile * np.sin( (psi + azimuth) * np.pi / 180) * np.cos(elevation * np.pi / 180)
        self._missile_state["w"] = V_missile * np.sin(elevation * np.pi / 180) 
        self._sim.run_ic()

        self.ac_traj.append(self._aircraft_position)
        self.ms_traj.append([self._missile_state["u"], self._missile_state["v"], self._missile_state["w"]])
        
    def _get_aircraft_state(self):
        state = []
        for prop, scale in self._aircraft_sim_props:
                state.append(self._sim[prop] * scale)
        return np.array(self._aircraft_position + state).astype(np.float32)

    def _get_missile_state(self):
        keys = ["x", "y", "z", "u", "v", "w"]
        state = [self._missile_state[k] for k in keys]

        return np.array(state, dtype=np.float32)
        
    def _update_states(self):
        self._aircraft_position[0] += self._sim["velocities/v-east-fps"] * 0.3048 * self._dt
        self._aircraft_position[1] += self._sim["velocities/v-north-fps"] * 0.3048 * self._dt
        self._aircraft_position[2] += -self._sim["velocities/v-down-fps"] * 0.3048 * self._dt

        ac_state = self._get_aircraft_state()
        missile_state = self._get_missile_state()
        
        r = ac_state[:3] - missile_state[:3]      
        v_r = ac_state[3:6] - missile_state[3:6] 
        
        r_mag = np.linalg.norm(r) + 1e-6
        v_r_mag = np.linalg.norm(v_r) + 1e-6
        
        omega_LOS = np.cross(r, v_r) / (r_mag ** 2 + 1e-6)
        
        a_cmd = -self.N * v_r_mag * np.cross(r, omega_LOS) / (r_mag + 1e-6)
        a_cmd_mag = np.linalg.norm(a_cmd)

        if a_cmd_mag > self._max_overload:
            a_cmd = a_cmd * (self._max_overload / a_cmd_mag)

        v_missile_new = missile_state[3:6] + a_cmd * self._dt
        v_missile_new = self._initial_V_missile * (v_missile_new) / (np.linalg.norm(v_missile_new))
        
        pos_current = np.array([self._missile_state[k] for k in ["x","y","z"]])
        pos_missile_new = pos_current + v_missile_new * self._dt
        
        keys = ["x","y","z","u","v","w"]
        for i, key in enumerate(keys):
            if i < 3:
                self._missile_state[key] = pos_missile_new[i]
            else:
                self._missile_state[key] = v_missile_new[i-3]

    def _get_obs(self):
        return {"aircraft": self._get_aircraft_state()[3:], "missile": self._get_missile_state() - self._get_aircraft_state()[:6]} 
    
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)

        self._set_initial_state()
        self._step_count = 0
        observation = self._get_obs()

        self.ac_traj = []
        self.ms_traj = []

        self._prev_lam = None
        info = {}
        info["states"] = [self._get_aircraft_state(), self._get_missile_state()]
        info = {
            "initial_conditions": {
                k: v for k, v in self.__dict__.items()
                if k.startswith("_initial_")
            }
        }

        return observation, info
        
    def _compute_reward(self):
        reward_dict = {}
        reward_dict["Reward"] = 1
        return 1, reward_dict

    def step(self, action):
        self._sim["fcs/elevator-cmd-norm"] = float(action[0])
        self._sim["fcs/aileron-cmd-norm"] = float(action[1])
        self._sim["fcs/rudder-cmd-norm"] = float(action[2])
        self._sim["fcs/throttle-cmd-norm"] = float(action[3])

        self._sim.run()
        self._step_count += 1

        self._prev_aircraft_position = self._aircraft_position
        self._prev_missile_position = [self._missile_state["x"], self._missile_state["y"], self._missile_state["z"]]

        self._update_states()

        ac_state = self._get_aircraft_state()
        missile_state = self._get_missile_state()

        self.ac_traj.append(ac_state[:3])
        self.ms_traj.append(missile_state[:3])

        observation = self._get_obs()
        reward, info = self._compute_reward()
        terminated = False
        truncated = False

        info["states"] = [ac_state, missile_state]
        info["Signed LOS"] = self._prev_lam if self._prev_lam is not None else 0
        
        dr = np.linalg.norm(missile_state[:3] - ac_state[:3])
        info["Distance"] = dr

        if dr <= self._lethal_radius:
            terminated = True
            info["terminated"] = "lethal radius"
            info["Steps"] = self._step_count
        
        if self._aircraft_position[2] <= self._min_height:
            terminated = True
            info["terminated"] = "below minimum height"
            info["Steps"] = self._step_count

        if self._step_count >= self._max_steps:
            truncated = True
            info["truncated"] = "max steps reached"
        
        return observation, reward, terminated, truncated, info

    def render(self):
        if self.render_mode == "human":
            ac_traj = np.array(self.ac_traj)
            ms_traj = np.array(self.ms_traj)

            fig = go.Figure()

            fig.add_trace(go.Scatter3d(
                x=ac_traj[:,0],
                y=ac_traj[:,1],
                z=ac_traj[:,2],
                mode='lines+markers',  
                name='Aircraft',
                line=dict(color='blue', width=4),
                marker=dict(size=4)
            ))

            fig.add_trace(go.Scatter3d(
                x=ms_traj[:,0],
                y=ms_traj[:,1],
                z=ms_traj[:,2],
                mode='lines+markers',
                name='Missile',
                line=dict(color='red', width=4),
                marker=dict(size=4)
            ))

            fig.add_trace(go.Scatter3d(
                x=[ac_traj[0,0]],
                y=[ac_traj[0,1]],
                z=[ac_traj[0,2]],
                mode='markers',
                marker=dict(color='blue', size=8, symbol='circle'),
                name='Aircraft Start'
            ))

            fig.add_trace(go.Scatter3d(
                x=[ms_traj[0,0]],
                y=[ms_traj[0,1]],
                z=[ms_traj[0,2]],
                mode='markers',
                marker=dict(color='red', size=8, symbol='circle'),
                name='Missile Start'
            ))

            fig.update_layout(
                scene=dict(
                    xaxis_title='X',
                    yaxis_title='Y',
                    zaxis_title='Z'
                ),
                title='3D Trajectories'
            )

            fig.show()  