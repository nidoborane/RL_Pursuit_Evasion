import gymnasium as gym
from .aircraft_missile_env import BaseEnv
import numpy as np

class SteepTurnEnv(BaseEnv):
    def _init_(self, render_mode=None):
        super().__init__(render_mode=render_mode)
        self._initial_roll = 85
        self._initial_pitch = 0
        
    def _compute_reward(self):
        reward_dict = {}

        w_roll = 0.5
        w_pitch = 0.5
        
        phi_star = 85.0 
        theta_star = 0.0

        tau_roll = 20
        tau_pitch = 20

        ac_state = self._get_aircraft_state()
        ms_state = self._get_missile_state()

        dx = ms_state[:3] - ac_state[:3]
        v_a = ac_state[3:6]

        phi = ac_state[6]
        theta = ac_state[7]

        r_roll = np.exp(-np.abs((phi - np.sign(np.cross(dx, v_a)[2]) * phi_star) / tau_roll)).astype(np.float32)
        r_pitch = np.exp(-np.abs((theta - theta_star) / tau_pitch)).astype(np.float32)
        
        reward_dict["Roll reward"] = r_roll
        reward_dict["Pitch reward"] = r_pitch

        return w_roll * r_roll + w_pitch * r_pitch, reward_dict
    