import gymnasium as gym
from .aircraft_missile_env import BaseEnv
import numpy as np

class ShortDistanceEnv(BaseEnv):
    def _compute_reward(self):
        reward_dict = {}

        ac_state = self._get_aircraft_state()
        ms_state = self._get_missile_state()

        dx_prev = [self._prev_missile_position[i] - self._prev_aircraft_position[i] for i in range(3)]
        dx_curr = ms_state[:3] - self._aircraft_position

        u_prev = dx_prev / np.linalg.norm(dx_prev)
        u_curr = dx_curr / np.linalg.norm(dx_curr)

        w_roll = 0.5
        w_pitch = 0.5
        w_los = 0.6

        phi_star = 85.0
        theta_star = 0.0

        tau_roll = 20
        tau_pitch = 20
        tau_los = 20

        v_a = ac_state[3:6]

        phi = ac_state[6]
        theta = ac_state[7]

        r_roll = np.exp(-np.abs((phi - np.sign(np.cross(dx_curr, v_a)[2]) * phi_star) / tau_roll)).astype(np.float32)
        r_pitch = np.exp(-np.abs((theta - theta_star) / tau_pitch)).astype(np.float32)

        lam = np.sign(np.cross(u_prev, u_curr)[2]) * np.linalg.norm(u_curr - u_prev) / self._dt

        if self._prev_lam is not None:
            lam = 0.25 * lam + 0.75 * self._prev_lam
        self._prev_lam = lam

        r_los = np.tanh(np.sign(np.cross(dx_prev, dx_curr)[2]) * lam / tau_los).astype(np.float32)

        reward_dict["Roll reward"] = r_roll
        reward_dict["Pitch reward"] = r_pitch
        reward_dict["LOS reward"] = r_los

        return w_roll * r_roll + w_pitch * r_pitch + w_los * r_los, reward_dict