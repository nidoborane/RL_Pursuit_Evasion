import gymnasium as gym

gym.register(id='AirMissileEnv-v0', entry_point='envs.aircraft_missile_env:BaseEnv')
gym.register(id="AirMissileEnv-SteepTurn-v0", entry_point='envs.steep_turn_env:SteepTurnEnv')
gym.register(id="AirMissileEnv-ShortDistance-v0", entry_point='envs.short_distance_env:ShortDistanceEnv')
gym.register(id="AirMissileEnv-SmallAzimuth-v0", entry_point='envs.small_azimuth_env:SmallAzimuthEnv')
gym.register(id="AirMissileEnv-LargeAzimuth-v0", entry_point='envs.large_azimuth_env:LargeAzimuthEnv')
