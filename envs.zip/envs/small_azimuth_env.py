import gymnasium as gym
from .aircraft_missile_env import BaseEnv
import numpy as np

class SmallAzimuthEnv(BaseEnv):
    def __init__(self, config, render_mode=None):
        super().__init__(config=config, render_mode=render_mode)

        self._initial_V_aircraft = self._V_aircraft_init()
        self._initial_d_missile = self._d_init()

        self._termination_distance = 5000

    def _V_aircraft_init(self):
        intervals = [(280, 320),
                     (320, 360),
                     (360, 400),
                     (400, 440),
                     (440, 470)]
        
        probabs = np.array([16, 8, 4, 2, 1], dtype=np.float32)
        probabs /= np.sum(probabs)
        low, high = intervals[np.random.choice(len(intervals), p=probabs)]
        return self.np_random.uniform(low, high)

    def _d_init(self):
        intervals = [(5000, 7000),
                     (7000, 9000),
                     (9000, 11000),
                     (11000, 13000),
                     (13000, 15000)]
        probabs = np.array([1, 2, 4, 8, 16], dtype=np.float32)
        probabs /= np.sum(probabs)
        low, high = intervals[np.random.choice(len(intervals), p=probabs)]
        return self.np_random.uniform(low, high)

    def _compute_azimuth(self):
        v_ac = self._get_aircraft_state()[3:5]
        v_ms = self._get_missile_state()[3:5]
        cross_prod = np.cross(v_ac, v_ms)
        az = np.dot(v_ac, v_ms) / (np.linalg.norm(v_ac) * np.linalg.norm(v_ms))
        
        return az if cross_prod >= 0.0 else -az

    def _compute_reward(self):
        reward_dict = {}

        ac_state = self._get_aircraft_state()
        ms_state = self._get_missile_state()

        phi_max = 135.0
        tau_roll = 20
        P_roll = -20.0

        phi = ac_state[6]
        r_roll = 0.5 * np.exp(-np.abs(phi) / tau_roll).astype(np.float32)
        c_roll = P_roll if np.abs(phi) > phi_max else 0.0

        theta_max = 22.5
        theta_star = 0.0
        tau_pitch = 20
        P_pitch = -20.0

        theta = ac_state[7]
        r_pitch = 0.5 * np.exp(-np.abs(theta - theta_star) / tau_pitch).astype(np.float32)
        c_pitch = P_pitch if np.abs(theta) > theta_max else 0.0

        azimuth_max = 30.0
        tau_azimuth = 20
        P_azimuth = -20.0

        azimuth = self._compute_azimuth()
        r_azimuth = np.exp(-np.abs(azimuth) / tau_azimuth).astype(np.float32)
        c_azimuth = P_azimuth if np.abs(azimuth) > azimuth_max else 0.0

        v_min = 240.0
        v_max = 510.0
        v_ref = 350.0
        tau_vel = 80.0
        P_vel = -20.0
        
        v = np.linalg.norm(ac_state[3:6])
        r_vel = 0.2 * np.tanh((v - v_ref) / tau_vel)
        c_vel = P_vel if (v > v_max or v < v_min) else 0.0

        reward_dict["Roll reward"] = r_roll
        reward_dict["Pitch reward"] = r_pitch
        reward_dict["Azimuth reward"] = r_azimuth
        reward_dict["Velocity reward"] = r_vel
        
        return r_roll + r_pitch + r_azimuth + r_vel + c_roll + c_pitch + c_azimuth + c_vel, reward_dict
    
    def step(self, action):
        observation, reward, terminated, truncated, info = super().step(action)

        ac_state = self._get_aircraft_state()
        missile_state = self._get_missile_state()
        
        dr = np.linalg.norm(missile_state[:3] - ac_state[:3])
        info["Distance"] = dr

        if dr <= self._termination_distance:
            terminated = True
            info["terminated"] = "distance less than 5000m"
            info["Steps"] = self._step_count
                
        return observation, reward, terminated, truncated, info
